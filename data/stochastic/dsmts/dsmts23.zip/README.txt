$LastChangedDate: 2006-04-17 09:17:19 +0100 (Mon, 17 Apr 2006) $
$Rev: 42 $
$Author: colin $

The Discrete Stochastic Model Test Suite consists of a series of SBML
models together with brief descriptions of each one, and time-course
data which may be used to test the output from discrete stochastic
simulators.  

See the user guide in the file "dsmts-userguide.pdf" for further
information about the suite.

The latest version of the Test Suite is available at:

http://www.calibayes.ncl.ac.uk/Resources/dsmts/

together with credits and further information about how it should be
used.

